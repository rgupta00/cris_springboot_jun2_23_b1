package com.productapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Productapp02Application {

	public static void main(String[] args) {
		SpringApplication.run(Productapp02Application.class, args);
	}

}
