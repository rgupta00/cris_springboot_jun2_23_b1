package com.productapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Productapp01Application {

	public static void main(String[] args) {
		SpringApplication.run(Productapp01Application.class, args);
	}

}
